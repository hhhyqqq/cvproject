## YOLOX for OpenVINO

* [C++ Demo](./cpp)
* [Python Demo](./python)